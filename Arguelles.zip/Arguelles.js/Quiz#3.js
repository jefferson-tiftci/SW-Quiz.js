var number = -102;
if(number > 0){
console.log("The number is positive");
}else{
    console.log("The number is negative");
}
//ARGUELLES JEFFERSON

