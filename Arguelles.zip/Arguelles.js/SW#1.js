class Person{
    constructor(name, age, country, birthplace){
        this.name = name;
        this.age = age;
        this.country = country;
        this.birthplace = birthplace;
    }
    displayDetails() {
        console.log(`Name: ${this.name}`);
        console.log(`age: ${this.age}`);
        console.log(`country: ${this.country}`);
        console.log(`birthplace: ${this.birthplace}`);
    }
 }
 const person1 = new Persona('Jefferson Arguelles', 19, 'philippine','rizal');
 const person2 = new Person('Juan Batongbakal', 18, 'china','beijing');
 const person3 = new Person('Nokia Rieza', 22, 'Taiwan',''taiwan'');
 const person4 = new Person('Naruto Uzumaki', 19, 'japan','kunoha');
 
 console.log('Persona-1 Details:');
 person1.displayDetails();

 console.log('\nPersona-2 Details:');
 person2.displayDetails();

 console.log('\nPersona-3 Details:');
 person3.displayDetails();

 console.log('\nPersona-4 Details:');
 person3.displayDetails();
//ARGUELLES JEFFERSON

