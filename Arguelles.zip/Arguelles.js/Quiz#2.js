var num1 = 99;
var num2 = 100;
if(num1 > num2){
console.log("num1 is greater");
}else{
    console.log("num2 greater");
}
//ARGUELLES JEFFERSON

