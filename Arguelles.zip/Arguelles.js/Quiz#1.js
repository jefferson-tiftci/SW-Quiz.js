var number = 50;
if(number % 2 ===0){
console.log("The number is even");
}else{
    console.log("The number is odd");
}
//ARGUELLES JEFFERSON C.

