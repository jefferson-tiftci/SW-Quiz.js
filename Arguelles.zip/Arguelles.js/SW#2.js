class Vehicle { 
    constructor(make, model, year, owner) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.owner = owner;
    }
    displayDetails() {  
        console.log(`Make: ${this.make}`);
        console.log(`Model: ${this.model}`);
        console.log(`Year: ${this.year}`);
        console.log(`Owner: ${this.owner}`);
    }
}

class Car extends Vehicle { 
    constructor(make, model, year, owner, doors) {  
        super(make, model, year, owner);  
        this.doors = doors;
    }
    displayDetails() {
        super.displayDetails(); 
        console.log(`Doors: ${this.doors}`);
    }
}

const vehicle = new Vehicle('Ford', 'F-150', 2020, 'Jefferson C. Arguelles');  

console.log('Vehicle Details:');
vehicle.displayDetails();

const car = new Car('Honda', 'Accord', 2023, 'Juan Mambobola', 4);  

console.log('\nCar Details:');
car.displayDetails();

const car1 = new Car('Jeep', 'F-1', 1999, 'Julio Manlanhit', 2);  

console.log('\nCar Details:');
car.displayDetails();

//ARGUELLES JEFFERSON

