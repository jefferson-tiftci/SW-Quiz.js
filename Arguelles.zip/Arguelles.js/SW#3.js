var number = 50;
if(number % 2 ===0){
console.log("it is even number");
}else{
    console.log("it is odd number");
}
//ARGUELLES JEFFERSON
